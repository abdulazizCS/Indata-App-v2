//
//  IUTableViewCell.swift
//  NDHpple
//
//  Created by IUPUI on 2/18/16.
//  Copyright © 2016 Nicolai Davidsson. All rights reserved.
//

import UIKit

class IUTableViewCell: UITableViewCell {

    

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
